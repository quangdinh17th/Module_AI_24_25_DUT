# Modulel_AI_24_25
# Using Python language for this Module
